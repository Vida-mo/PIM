package jol20kuz.springairagollamademo.configuration;

import jol20kuz.springairagollamademo.experiment.Experiment;
import jol20kuz.springairagollamademo.service.ExperimentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Configuration;

import java.util.Collection;

@Configuration
public class PerformExperimentsConfiguration {

    @Autowired
    public PerformExperimentsConfiguration(ExperimentService experimentService, Collection<Experiment> experiments) {
        experiments.forEach(experimentService::performExperiment);
        System.exit(0);
    }


}
