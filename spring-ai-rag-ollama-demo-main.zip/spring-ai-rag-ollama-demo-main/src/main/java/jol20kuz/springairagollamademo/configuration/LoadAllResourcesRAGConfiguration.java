package jol20kuz.springairagollamademo.configuration;

import jol20kuz.springairagollamademo.experiment.Experiment;
import jol20kuz.springairagollamademo.service.ExperimentService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.IOException;
import java.nio.file.Path;
import java.util.*;

/**
 * Lädt alle Quellen aus dem static/sources-Verzeichnis und lässt diese vom RAG Service in die Vektor-Datenbank einlesen.
 */
@Configuration
public class LoadAllResourcesRAGConfiguration {

    private static final Logger LOG = LoggerFactory.getLogger(LoadAllResourcesRAGConfiguration.class);

    private Resource[] sources, prompts;

    @Autowired
    public LoadAllResourcesRAGConfiguration(
            @Value("classpath:/static/sources/*/*") Resource[] sources,
            @Value("classpath:/static/prompts/*/*.p*mpt") Resource[] prompts
    ) {
        this.sources = sources;
        this.prompts = prompts;
        LOG.info("Initializing RAG configuration with resources: {}, {}", sources, prompts);
    }

    @Bean
    public Collection<Experiment> experiments() {
        HashMap<String, Experiment> experiments = new HashMap<>();
        loadAllSourcesIntoMap(experiments);
        loadAllPromptsIntoMap(experiments);

        LOG.info("Loaded experiments: {}", experiments.values().stream().map(Experiment::getName).toArray());

        return experiments.values();
    }

    private void loadAllSourcesIntoMap(Map<String, Experiment> experiments) {
        Arrays.stream(sources).forEach(source -> {
            try {
                Path path = source.getFile().toPath();
                String experimentName = path.getParent().getFileName().toString();

                Experiment experiment = experiments.computeIfAbsent(experimentName, Experiment::new);
                experiment.addSource(source);
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private void loadAllPromptsIntoMap(Map<String, Experiment> experiments) {
        Arrays.stream(prompts).forEach(prompt -> {
            try {
                Path path = prompt.getFile().toPath();
                String experimentName = path.getParent().getFileName().toString();

                Experiment experiment = experiments.computeIfAbsent(experimentName, Experiment::new);
                experiment.addPrompt(prompt);
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private Set<Resource> resourcesToRead() {
        throw new UnsupportedOperationException("Not implemented");
    }

}
