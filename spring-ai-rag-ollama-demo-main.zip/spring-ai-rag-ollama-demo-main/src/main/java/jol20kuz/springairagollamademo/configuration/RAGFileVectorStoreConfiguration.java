package jol20kuz.springairagollamademo.configuration;

import jol20kuz.springairagollamademo.experiment.ExperimentVectorStore;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.SimpleVectorStore;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;

import java.io.IOException;

@Configuration
public class RAGFileVectorStoreConfiguration {

    @Value("classpath:static/vector_store.json")
    private Resource vectorStoreResource;

    @Bean
    public ExperimentVectorStore simpleVectorStore(EmbeddingModel embeddingModel) throws IOException {
        return new ExperimentVectorStore(embeddingModel, vectorStoreResource.getFile());
    }

}
