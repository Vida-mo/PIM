package jol20kuz.springairagollamademo.service;

import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.core.io.Resource;

public interface RAGService {

    void addText(String text);
    void addTextDocument(Resource resource);
    Prompt buildPrompt(String prompt);
    void resetVectorStore();

}
