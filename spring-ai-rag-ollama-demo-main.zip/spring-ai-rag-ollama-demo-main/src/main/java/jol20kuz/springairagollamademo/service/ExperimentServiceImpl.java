package jol20kuz.springairagollamademo.service;

import jol20kuz.springairagollamademo.experiment.Experiment;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.reader.TextReader;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.Arrays;

@Service
public class ExperimentServiceImpl implements ExperimentService {

    private static final Logger LOG = LoggerFactory.getLogger(ExperimentServiceImpl.class);

    private final RAGService ragService;
    private final ChatService chatService;

    @Value("${experiment.perform:}")
    private String[] performExperiments;

    @Autowired
    public ExperimentServiceImpl(RAGService ragService, ChatService chatService) {
        this.ragService = ragService;
        this.chatService = chatService;
    }

    @Override
    public void performExperiment(Experiment experiment) {
        if (!shouldPerform(experiment)) {
            LOG.info("Skipping experiment: {}", experiment);
            return;
        }

        LOG.info("Performing experiment: {}", experiment);
        ragService.resetVectorStore();

        experiment.getSources().forEach(ragService::addTextDocument);

        experiment.getPrompts().forEach(promptResource -> {
            try {
                Path path = promptResource.getFile().toPath();
                String promptName = path.getFileName().toString();
                String prompt = Files.readString(path);

                LOG.info("Prompting RAG service with prompt \"{}\": {}", promptName, prompt);
                Prompt buildPrompt = ragService.buildPrompt(prompt);
                var response = chatService.prompt(buildPrompt);

                Path buildPath = Paths.get(path.getParent().toString(), promptName + ".build");
                Files.writeString(buildPath, buildPrompt.getContents());

                Path responsePath = Paths.get(path.getParent().toString(), promptName + ".response");
                Files.writeString(responsePath, response.getResult().getOutput().getContent());
            }
            catch (IOException e) {
                throw new RuntimeException(e);
            }
        });
    }

    private boolean shouldPerform(Experiment experiment) {
        if (performExperiments.length <= 0) return true;

        return Arrays.stream(performExperiments).filter(s -> experiment.getName().equals(s)).toList().size() == 1;
    }
}
