package jol20kuz.springairagollamademo.service;

import jol20kuz.springairagollamademo.experiment.Experiment;

public interface ExperimentService {

    void performExperiment(Experiment experiment);

}
