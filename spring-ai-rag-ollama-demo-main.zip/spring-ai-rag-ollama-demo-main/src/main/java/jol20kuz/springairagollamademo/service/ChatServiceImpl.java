package jol20kuz.springairagollamademo.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.model.ChatModel;
import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class ChatServiceImpl implements ChatService {

    private static final Logger LOG = LoggerFactory.getLogger(ChatServiceImpl.class);

    private final ChatModel chatModel;

    @Autowired
    public ChatServiceImpl(ChatModel chatModel) {
        this.chatModel = chatModel;
        LOG.info("ChatServiceImpl initialized with chat model: {}", chatModel);
    }

    @Override
    public String prompt(String promptText) {
        Prompt prompt = new Prompt(promptText);
        return prompt(prompt).getResult().getOutput().getContent();
    }

    @Override
    public ChatResponse prompt(Prompt prompt) {
        LOG.info(
                "Prompting chat model with prompt \"{}\"",
                prompt.getContents().substring(0, Math.min(15, prompt.getContents().length()))
        );
        var response = chatModel.call(prompt);
        LOG.info(
                "Chat model response for prompt \"{}\" is \"{}\"",
                prompt.getContents().substring(0, Math.min(15, prompt.getContents().length())),
                response.getResult().getOutput().getContent().substring(0,
                        Math.min(15, response.getResult().getOutput().getContent().length())
                )
        );
        return response;
    }
}
