package jol20kuz.springairagollamademo.service;

import jol20kuz.springairagollamademo.experiment.ExperimentVectorStore;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.ai.chat.prompt.Prompt;
import org.springframework.ai.chat.prompt.PromptTemplate;
import org.springframework.ai.document.Document;
import org.springframework.ai.reader.TextReader;
import org.springframework.ai.transformer.splitter.TokenTextSplitter;
import org.springframework.ai.vectorstore.SearchRequest;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.Resource;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;

@Service
public class RAGServiceImpl implements RAGService {

    private static final Logger LOG = LoggerFactory.getLogger(RAGServiceImpl.class);

    private final ExperimentVectorStore vectorStore;

    @Value("${spring.ai.vectorstore.mongodb.collection-name}")
    private String collectionName;

    @Value("classpath:templates/prompt/RAGPrompt")
    private Resource ragPromptResource;

    @Autowired
    public RAGServiceImpl(ExperimentVectorStore vectorStore) {
        this.vectorStore = vectorStore;
        LOG.info("RAGServiceImpl initialized with vector store: {}", vectorStore);
    }

    @Override
    public void addText(String text) {
        TokenTextSplitter tokenTextSplitter = new TokenTextSplitter();
        var documents = tokenTextSplitter.apply(List.of(new Document(text)));

        LOG.info("Adding documents to vector store: {}", documents);

        vectorStore.add(documents);
    }

    @Override
    public void addTextDocument(Resource resource) {
        TextReader textReader = new TextReader(resource);
        var documents = textReader.read();

        LOG.info("Adding documents to vector store: {}", documents);

        vectorStore.add(documents);
    }

    @Override
    public Prompt buildPrompt(String promptText) {
        PromptTemplate prompt = new PromptTemplate(ragPromptResource);
        var documents = vectorStore.similaritySearch(SearchRequest.query(promptText).withTopK(2)); // todo: warum funktioniert das nicht?

        LOG.info("Building prompt with context: {}, prompt: \"{}\"", documents, promptText);

        prompt.add("context",
                documents.stream().map(Document::getContent).reduce((a, b) -> a + "\n\n\n\n\n" + b).get());
        prompt.add("prompt", promptText);
        return new Prompt(prompt.render());
    }

    @Override
    public void resetVectorStore() {
        LOG.info("Resetting vector store");
        try {
            vectorStore.reset();
        } catch (IOException e) {
            throw new RuntimeException(e);
        }
    }
}