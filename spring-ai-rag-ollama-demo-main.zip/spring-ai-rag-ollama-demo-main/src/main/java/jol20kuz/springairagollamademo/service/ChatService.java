package jol20kuz.springairagollamademo.service;

import org.springframework.ai.chat.model.ChatResponse;
import org.springframework.ai.chat.prompt.Prompt;

public interface ChatService {

    String prompt(String prompt);
    ChatResponse prompt(Prompt prompt);

}
