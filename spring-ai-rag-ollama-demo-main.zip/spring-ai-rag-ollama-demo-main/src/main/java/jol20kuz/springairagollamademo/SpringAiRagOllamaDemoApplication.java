package jol20kuz.springairagollamademo;

import jol20kuz.springairagollamademo.service.ChatService;
import jol20kuz.springairagollamademo.service.RAGService;
import org.springframework.ai.vectorstore.VectorStore;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;

@SpringBootApplication
public class SpringAiRagOllamaDemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringAiRagOllamaDemoApplication.class, args);
    }
}

