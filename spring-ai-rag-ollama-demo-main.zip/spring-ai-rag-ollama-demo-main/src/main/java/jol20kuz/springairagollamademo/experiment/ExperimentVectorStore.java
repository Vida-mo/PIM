package jol20kuz.springairagollamademo.experiment;

import org.springframework.ai.document.Document;
import org.springframework.ai.embedding.EmbeddingModel;
import org.springframework.ai.vectorstore.SimpleVectorStore;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.util.List;

public class ExperimentVectorStore extends SimpleVectorStore {

    private final File vectorStoreResource;

    public ExperimentVectorStore(EmbeddingModel embeddingModel, File vectorStoreResource) {
        super(embeddingModel);
        this.vectorStoreResource = vectorStoreResource;
        load(vectorStoreResource);
    }

    @Override
    public void add(List<Document> documents) {
        super.add(documents);
        vectorStoreResource.delete();
        save(vectorStoreResource);
    }

    public void reset() throws IOException {
        Files.writeString(vectorStoreResource.toPath(), "{}");
        load(vectorStoreResource);
    }
}
