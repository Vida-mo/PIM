package jol20kuz.springairagollamademo.experiment;

import org.springframework.core.io.Resource;

import java.util.Collections;
import java.util.HashSet;
import java.util.Set;

public class Experiment {

    private final String name;

    private final Set<Resource> sources = new HashSet<>();
    private final Set<Resource> prompts = new HashSet<>();

    public Experiment(String name) {
        this.name = name;
    }

    public void addSource(Resource source) {
        sources.add(source);
    }

    public void addPrompt(Resource prompt) {
        prompts.add(prompt);
    }

    public String getName() {
        return name;
    }

    public Set<Resource> getSources() {
        return Collections.unmodifiableSet(sources);
    }

    public Set<Resource> getPrompts() {
        return Collections.unmodifiableSet(prompts);
    }

    @Override
    public String toString() {
        return getName();
    }
}
