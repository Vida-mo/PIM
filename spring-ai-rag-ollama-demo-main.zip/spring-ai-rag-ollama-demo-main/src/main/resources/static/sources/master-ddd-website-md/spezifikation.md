Knowledge Crunching und Spezifikation :: SWT

[Home](http://homefgr.de) // [SWT](https://swt.homefgr.de)

Links

**GitHub**

[Kurs](https://github.fh-zwickau.de/whz-modul-pti09420-swt/)

- - -

[Teams](https://github.fh-zwickau.de/orgs/whz-modul-pti09420-swt/teams/studierende-2022ss)

- - -

**Erstellt mit**

[Antora](https://antora.org)

[![WHZ-Logo](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/WHZ-Logo.svg/1200px-WHZ-Logo.svg.png)](https://www.fh-zwickau.de/pti/organisation/fachgruppe-informatik/homepage-der-fg-informatik/)

### [SWT](../index.html)

*   *   Überblick
    *   [Semesterplan](../semesterplan.html)
    *   [Semesterprojekt](../semesterprojekt.html)
*   *   Middleware
    *   [Zeitplan - Folien](../middleware/index.html)
    *   [Enterprise Application](../middleware/enterprise.html)
    *   [Entwickeln mit Spring](../middleware/spring.html)
    *   [Axon](../middleware/axon.html)
    *   [Axon und SAGA](../middleware/axon-saga.html)
    *   [Microservices](../middleware/microservices.html)
    *   [Projektaufbau](../middleware/microservices-implementing.html)
    *   [Security und OAuth2](../middleware/security-oauth2.html)
    *   [Eventual Consistency](../middleware/eventual-consistency.html)
    *   [Reaktive Anwendungen und Webflux](../middleware/reactive-programming.html)
    *   [Axon und Reactive](../middleware/reactive-axon.html)
    *   [Hexagonal Architecture](../middleware/hexagonal.html)
    *   [Pattern](../middleware/pattern.html)
*   *   DDD
    *   [Spezifikation](spezifikation.html)
    *   [DDD](ddd.html)
    *   [Praktikumsprojekt](praktikumsprojekt-2022.html)
*   *   Modellierung
    *   [Grundlagen](../modellierung/index.html)
    *   Ecore
        *   [Einführung](../modellierung/ecore.html)
    *   Xtext
        *   [Einführung](../modellierung/xtext.html#einfuehrung)
        *   [DSL für Zustandsautomaten](../modellierung/xtext.html#fowler-dsl)
        *   [Übung: DSL für DDD](../modellierung/xtext.html#ddd-dsl)

SWT 2024

*   [SWT](../index.html)

    *   [2024](../index.html)
    *   [2023](../../2023/index.html)

[](../index.html)

*   [SWT](../index.html)
*   DDD
*   [Spezifikation](spezifikation.html)

2024

[2024](spezifikation.html) [2023](../../2023/ddd/spezifikation.html)

[Edit this Page](https://github.fh-zwickau.de/whz-modul-pti09420-swt/swt-website/blob/main/2024/modules/ddd/pages/spezifikation.adoc)

# Knowledge Crunching und Spezifikation

(Letzte Änderung: 2024-07-25 22:04:03 +0200)

## [](#einordnung)1\. Einordnung

Dieses erste Themengebiet des Modellierungsteils des Kurses beschäftigt sich mit dem sogenannten _Knowledge Crunching_, durch das Softwareentwickler die Fachlichkeit (auch Geschäftslogik (engl.: Business Logic)) oder Problemdomäne bzw. des Problemraums verstehen lernen. Es ist für (ernstzunehmende) Softwareentwickler unabdingbar, die Fachlichkeit (im Englischen in etwas mit _subject matter_ übersetzbar) zu verstehen, um die zu lösenden Probleme dann fachlich sauber in Code abbilden zu können!

Ausgehend von den hier besprochenen Knowledge-Crunching-Techniken wenden wir uns im zweiten Schritt [Domain-Driven Design](ddd.html) zu, und lernen dort Techniken, um eine Fachdomäne sauber in Code abzubilden. Das heißt, im ersten Schritt lernen wir Techniken kennen, mit denen wir durch Zusammenarbeit mit Fachleuten, deren fachliches Domänenwissen zu Tage fördern, verstehen und beschreiben können. Im zweiten Schritt überführen wir dieses Wissen mithilfe von DDD in eine Softwarelösung, die die Konzepte der Fachdomäne, die wir Softwareentwickler zur Implementierung der Lösung benötigen, sauber in Code widerspiegelt.

Die technische Realisierung dieser Überführung wird im Middleware-Teil des Kurses besprochen — parallel zum Modellierungsteil, bei dem es nicht vorrangig um die Implementierung (sprich: Code) geht.

Im ersten Teil des Kurses lernen wir Techniken kennen, mit denen fachliche Abläufe visualisiert werden können, sodass Fachleute und Softwareentwickler sie verstehen können.

Eine gute Beschreibung dieses Ansatzes finden Sie hier: [https://leanpub.com/visualcollaborationtools](https://leanpub.com/visualcollaborationtools).

## [](#zentrales-element-domain-events)2\. Zentrales Element: Domain Events

> “The universe is made of events not objects.”

— Carlo Rovelli (https://de.wikipedia.org/wiki/Carlo\_Rovelli)

Fachleute (Domänenexperten) können Abläufe innerhalb einer Domäne oft sehr gut mithilfe von fachlichen Ereignissen (engl.: _domain events_) beschreiben. Die verschiedenen Techniken zum _Knowledge Crunching_, die wir verwenden, haben alle gemein, dass Domain Events verwendet werden, um Geschäftsprozesse zu beschreiben.

> “Life is a stream of events.” (“Livet er en strøm av hendelser.”)

— Motto der Norwegian Labour and Welfare Administration (NAV)  
wenn es um das Erstellen von Softwaresystemen geht.

## [](#einstieg-in-den-kurs)3\. Einstieg in den Kurs

Wir verwenden zunächst Techniken des kollaborativen Softwareentwurfs (engl.: _Collaborative Software Design_), um Knowledge Crunching zu betreiben. Die Techniken, die wir verwenden sind: EventStorming (genauer: Big-Picture-EventStorming), Domain Storytelling und Event Modeling.

### [](#einführung-in-domain-storytelling)3.1. Einführung in Domain Storytelling

Siehe [https://domainstorytelling.org/quick-start-guide](https://domainstorytelling.org/quick-start-guide).

### [](#einführung-in-event-modeling)3.2. Einführung in Event Modeling

Quelle: [https://eventmodeling.org/posts/what-is-event-modeling/](https://eventmodeling.org/posts/what-is-event-modeling/)

#### [](#bestandteile)3.2.1. Bestandteile

1.  [Use-Case-Trigger](https://eventmodeling.org/posts/what-is-event-modeling/#wireframes) (UI/Wireframe, Public API oder automatisierter Prozess (vgl. _Cron Jobs_))

    *   Können in _Swim Lanes_ organisiert werden, um verschiedene Nutzerrollen/Personas zu repräsentieren.


2.  [Commands](https://eventmodeling.org/posts/what-is-event-modeling/#commands)

3.  [Domain Events](https://eventmodeling.org/posts/what-is-event-modeling/#events)

    *   Die aufgeführten Events müssen den spezifizierten Geschäftsprozess vollständig beschreiben.

    *   Events sind unveränderlich, sie werden in der Vergangenheitsform benannt.

    *   Sie haben einen Zeitstempel, der den Zeitpunkt ihres Auftretens darstellt.

    *   Können in _Swim Lanes_ organisiert werden, um Zugehörigkeit zu Bounded Context (vgl. DDD) oder Subsystem darzustellen.


4.  [Views](https://eventmodeling.org/posts/what-is-event-modeling/#views) (auch als _Read Models_ bekannt)


#### [](#muster)3.2.2. Muster

Beim Event Modeling werden die oben beschriebenen “Einzelteile” verwendet, um mit ihrer Hilfe vier Muster zu formen, mit denen fachliche Abläufe (nicht nur in Informationssystemen) beschrieben werden können (siehe auch [https://eventmodeling.org/posts/event-modeling-cheatsheet/](https://eventmodeling.org/posts/event-modeling-cheatsheet/) und [Building Information Systems using Event Modeling (Bobby Calderwood, Evident Systems) Kafka Summit 2020](https://videos.confluent.io/watch/uw9bRczCiYMoHTcGJYtjau)):

*   [Command Pattern](https://eventmodeling.org/posts/what-is-event-modeling/#commands) (auch genannt: State Change Pattern, durch Command ausgelöster Event stellt Änderung im System dar)

    *   Command löst Transaktion im System aus; Abschluss dieser Transaktion wird durch Domain Event repräsentiert.


*   [View Pattern](https://eventmodeling.org/posts/what-is-event-modeling/#views) (auch genannt: State-View-Muster)

    *   Repräsentation des aktuellen Zustands des Systems, der sich aus den vorher ereigneten Events ergibt.

    *   Es kann viele Views geben (die aus denselben Events abgeleitet wurden).


*   [Automation Pattern](https://eventmodeling.org/posts/what-is-event-modeling/#automation) mit Processors (auch genannt: External State Input Pattern)

    *   Für das vorliegende System bedeutsame Events werden aus Events aus anderen Systemen oder Low-Level-Events (oder anderen Informationen aus externen Systemen) erstellt.


*   [Integration](https://eventmodeling.org/posts/what-is-event-modeling/#integration) / [Translation](https://eventmodeling.org/posts/what-is-event-modeling/#translation) Pattern (auch genannt: External-State-Output-Muster)

    *   Wird verwendet, um eine _To-Do_\-Liste zu erstellen, die Aufgaben/Aktionen enthält, die externe Systeme ausführen sollen (um dort einen Effekt hervorzurufen); diese Liste wird durch ein Read Model repräsentiert.

    *   Diese Aktionen werden durch einen automatisierten Prozess mithilfe von Commands in den externen Systeme ausgelöst.

    *   Das Ergebnis (bzw. die Antwort des externen Systems) einer ausgelösten Aktion wird als Event im betrachteten System (sprich: in "unserem" System) festgehalten.

    *   Stellt Alternative zu Long-Running Process Pattern/Saga Pattern dar.



Diese Muster sind eng verbunden mit dem Konzept eines “Slice”:

*   Ein Schritt in einem Geschäftsprozess (wird im Event-Modeling-Diagram visualisiert)

*   2 Ausprägungen:

    1.  Zustand des Systems ändern (mithilfe von Commands und Events)

    2.  View des aktuellen Zustands des Systems



#### [](#fachliche-tests)3.2.3. Fachliche Tests

Wir Menschen lernen besser durch Beispiele als durch abstrakte Beschreibung von Regeln. Event Modeling verwendet den (bewiesenermaßen funktionierenden) Ansatz des _Specification by Example_ zur Beschreibung von fachlichen Abläufen — erfolgreichen Abläufen und solchen, die fehlschlagen, weil fachliche Vorbedingungen nicht erfüllt sind.

Event Modeling verwendet dafür den _Given-When-Then_\-Ansatz:

1.  Mithilfe von Events wird eine Ausgangssituation hergestellt,

2.  anschließend wird ein Command ausgelöst,

3.  der letztlich zu Zustandsänderungen im System führt, die durch Domain Events repräsentiert werden.


(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#commands](https://eventmodeling.org/posts/what-is-event-modeling/#commands))

#### [](#beispiel)3.2.4. Beispiel

##### [](#gesamtmodell)Gesamtmodell:

(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#the-model-that-works](https://eventmodeling.org/posts/what-is-event-modeling/#the-model-that-works))

![Gesamtsystem](_images/eventmodelling-blueprint_large.jpg)

##### [](#events-und-wireframes)Events und Wireframes:

(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#wireframes](https://eventmodeling.org/posts/what-is-event-modeling/#wireframes))

![Events](_images/eventmodelling-events_large.jpg)

Das Beispiel zeigt:

*   Wireframes sind _Swim Lanes_ für Nutzerrollen _Guest_ und _Manager_ zugeordnet.

*   Events sind _Swim Lanes_ zugeordnet, die die Subsysteme _Inventory_, _Auth_, _Payment_ und _GPS_ repräsentieren.


##### [](#state-change-pattern)State Change Pattern:

(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#commands](https://eventmodeling.org/posts/what-is-event-modeling/#commands))

*   Zustandsänderung im System, die durch Command ausgelöst und durch Event “festgehalten/verewigt” wird.


![Zustandsänderung](_images/eventmodelling-empower_large.jpg)

Das Beispiel zeigt:

1.  Nutzer klickt Button im UI

2.  _BookRoom_\-Command wird ausgelöst

3.  Geschäftslogik für Zimmerbuchung wird ausgeführt

4.  Falls Zimmerbuchung erfolgreich war, wird _RoomBooked_\-Event (im System) veröffentlicht.


##### [](#state-view-muster)State-View-Muster

(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#views](https://eventmodeling.org/posts/what-is-event-modeling/#views))

*   Aktueller Zustand (eines Teils) des Systems; kann durch verschiedene Read Models und Queries abgefragt werden.

*   Read Model ist eine Reduktion (bzw. _left fold_) aller bisherigen Events.


![eventmodelling inform large](_images/eventmodelling-inform_large.jpg)

Das Beispiel zeigt:

*   Wurde ein Zimmer gebucht, hat das Auswirkungen auf den Reinigungsplan — dieser muss aktualisiert werden.


##### [](#external-state-input-pattern)External State Input Pattern

(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#translation](https://eventmodeling.org/posts/what-is-event-modeling/#translation))

![eventmodelling understand large](_images/eventmodelling-understand_large.jpg)

Das Beispiel zeigt:

*   Low-Level-GPS-Events (von externem System erzeugt und nicht direkt für unser System verwertbar) werden durch Übersetzungskomponente in vom System verwertbare Commands überführt (die anschließend in Events resultieren).


##### [](#external-state-export-pattern)External State Export Pattern

(siehe auch [https://eventmodeling.org/posts/what-is-event-modeling/#automation](https://eventmodeling.org/posts/what-is-event-modeling/#automation))

![eventmodelling automate large](_images/eventmodelling-automate_large.jpg)

Das Beispiel zeigt:

*   Payment Processor (automatisierter Prozess) arbeitet auf Basis eines '"_Payments to Process_'"-Read-Models, das zu bearbeitende Zahlungsanforderungen enthält.

    *   Zahlungsanforderung heißt, dass Hotelgast Kosten seines Hotelaufenthalts begleichen soll.

    *   Für diese Bezahlung wird ein Payment-Gateway genutzt (um verschiedene Bezahldienstleister nutzen zu können)


*   Payment Processor liest Zahlungsanforderungen im Read Model in bestimmten Zeitintervallen oder als Reaktion auf Änderungen in diesem Read Model aus.

*   Payment Processor löst für jede Zahlungsanforderung einen entsprechenden Command im Payment Gateway aus.

*   Das Ergebnis dieses Commands wird als Event ins System zurückkommuniziert.


#### [](#keine-verzweigungen-in-fachlichen-abläufen)3.2.5. Keine Verzweigungen in fachlichen Abläufen

Wir Menschen verstehen lineare Abläufe (Sequenzen) besser als verzweigte Abläufe (Graphen). Daher werden in Event Modeling fachliche Prozesse, die unterschiedliche Teilabläufe haben (sprich: Verzweigungen), _nicht_ in ein und demselben Slice dargestellt, sondern in mehreren — jede fachliche Verzweigung führt zu einem separaten Slice (ohne Verzweigung).

#### [](#event-modeling-ablauf)3.2.6. Ablauf einer Event-Modeling-Session

Siehe [https://eventmodeling.org/posts/what-is-event-modeling/#seven-steps](https://eventmodeling.org/posts/what-is-event-modeling/#seven-steps):

1.  [Brain Storming](https://eventmodeling.org/posts/what-is-event-modeling/#brain-storming)

    *   Fachliche Ereignisse (Domain Events) zusammentragen


2.  [Plot: Events zeitlich einordnen](https://eventmodeling.org/posts/what-is-event-modeling/#the-plot)

3.  …​


(Mindestens) die ersten beiden Schritte des Event-Modeling-Ablaufs sind identisch zum Big-Picture-EventStorming.

## [](#übung)4\. Übung

### [](#ziele)4.1. Ziele

Ziel dieser Übung ist es, Ihnen einen Zugang zu Big-Picture-EventStorming, Domain Storytelling und Event Modeling zu geben. Anhand eines trivialen Beispiels: Verwaltung von Aufgaben (To-Do-Listen-Verwaltung).

Sie werden diese Techniken als Teil einer komplexeren [Hausaufgabe](#hausaufgabe-1) vertiefen.

### [](#domain-story)4.2. Domain Story

Hier ist eine (sehr einfache) Domain Story für die fachlichen Abläufe beim Verwalten von Aufgaben:

![aufgabenverwaltung 1](_images/aufgabenverwaltung-1.png)

Figure 1. Domain Story für die Verwaltung von Aufgaben (Version 1)

Hier ist diese Story zum Download: [aufgabenverwaltung-1.dst](_attachments/aufgabenverwaltung-1.dst). Sie können diese Datei im Domain-Story-Modellierungstool [https://www.wps.de/modeler/](https://www.wps.de/modeler/) verwenden.

### [](#event-modeling)4.3. Event Modeling

Aufgabe: Führen Sie die [sieben Schritte](#event-modeling-ablauf) des Event Modeling für die Aufgabenverwaltung durch.

Fragen:

1.  Welche fachlichen Ereignisse (Domain Events) gibt es?

2.  In welcher Reihenfolge treten die Events auf?

3.  Welche UI-Elemente sind notwendig?

4.  Welche Commands sind notwendig?

5.  Wann können Commands fehlschlagen?

6.  Welche Gegeben-Wenn-Dann-Abläufe gibt es?

7.  Welche fachlichen Abläufe sind (noch) beschrieben worden?


## [](#hausaufgabe-1)5\. Hausaufgabe

### [](#ziele-2)5.1. Ziele

*   Vertiefung Domain Storytelling

*   Vertiefung Event Modeling durch die Überführung fachlicher Abläufe, die mithilfe von Domain Storytelling beschrieben wurden, in ein Event-Modeling-Modell


### [](#hausaufgabe-1-aufgabe-1)5.2. Aufgabe 1

Erklären Sie Domain Storytelling anhand des hier beschriebenen Beispiels (Quelle: Kapitel 8 aus (Hofer & Schwentner, 2021)).

### [](#hausaufgabe-1-aufgabe-2)5.3. Aufgabe 2

Überführen Sie dieses Domain-Storytelling-Modell (Quelle: Kapitel 8 aus (Hofer & Schwentner, 2021)) in ein Event-Modeling-Modell.

## [](#einordnung-workflows-szenarien-und-use-cases)6\. Einordnung Workflows, Szenarien und Use Cases

Aus dem Buch _Domain Modeling made functional_ (S. 12f):

_We have many different words to describe business activities: "workflows," "scenarios," "use cases," "processes," and so on. They’re often used interchangeably; but in this book, we’ll try to be a bit more precise._

_A scenario describes a goal that a customer (or other user) wants to achieve, such as placing an order. It is similar to a "story" in agile development. A use case is a more detailed version of a scenario, which describes in general terms the user interactions and other steps that the user needs to take to accomplish a goal. Both scenario and use case are user-centric concepts, focused on how interactions appear from the user’s point of view._

_A business process describes a goal that the business (rather than an individual user) wants to achieve. It’s similar to a scenario but has a business-centric focus rather than a user-centric focus._

_A workflow is a detailed description of part of a business process. That is, it lists the exact steps that an employee (or software component) needs to do to accomplish a business goal or subgoal. We’ll limit a workflow to what a single person or team can do, so that when a business process is spread over multiple teams (as the ordering process is), we can divide the overall business process into a series of smaller workflows, which are then coordinated in some way._

## [](#literatur-und-weiterführendes-material)7\. Literatur und weiterführendes Material

### [](#collaborative-software-design)7.1. Collaborative Software Design

*   van Kelle, E., Verschatse, G., Baas-Schwegler, K. (2023). Collaborative Software Design: How to facilitate domain modeling decisions. Manning.


### [](#event-storming)7.2. Event Storming

*   Brandolini, A. (2021). Introducing EventStorming: An act of Deliberate Collective Learning. Leanpub.

*   [https://www.eventstorming.com/](https://www.eventstorming.com/)

*   [Sehr gute Einführung](https://medium.com/@springdo/a-facilitators-recipe-for-event-storming-941dcb38db0d)


### [](#domain-storytelling)7.3. Domain Storytelling

*   Hofer, S.; Schwentner, H. (2022). [Domain Storytelling: Mit guten Geschichten zu besseren Anforderungen](_attachments/domain_storytelling_itspektrum_06_2022_.pdf). IT Spektrum 06/2022.

*   Hofer, S.; Schwentner, H. (2021). Domain Storytelling: A Collaborative, Visual, and Agile Way to Build Domain-Driven Software. Addison-Wesley.

*   [Video: Introduction to Domain Storytelling](https://www.youtube.com/watch?v=d9k9Szkdprk)

*   [https://www.wps.de/modeler/](https://www.wps.de/modeler/)


### [](#domain-storytelling-und-ddd-in-einem-beispielprojekt)7.4. Domain Storytelling und DDD in einem Beispielprojekt

*   [https://leasingninja.io/](https://leasingninja.io/) von Henning Schwentner


### [](#event-modeling-2)7.5. Event Modeling

*   Dymitruk, A. (2019). [What is Event Modeling](https://eventmodeling.org/posts/what-is-event-modeling/)

*   Dymitruk, A. (2019). [Event Modeling Traditional Systems](https://eventmodeling.org/posts/event-modeling-traditional-systems/)

*   Bortz, S. (2020). [Event Modeling Cheat Sheet](https://eventmodeling.org/posts/event-modeling-cheatsheet/)

    *   Hier werden (u. a.) die vier in Event Modeling genutzten Muster kurz und prägnant erklärt.


*   Calderwood, B. (2020). [Event Modeling explained](https://www.onote.com/blog/event-modeling-explained/)

*   [https://eventmodeling.org/](https://eventmodeling.org/)

*   [https://www.se-radio.net/2022/11/episode-539-adam-dymitruk-on-event-modeling/](https://www.se-radio.net/2022/11/episode-539-adam-dymitruk-on-event-modeling/)

*   Event-Modeling-Tools:

    *   [https://www.onote.com/](https://www.onote.com/)

    *   [https://www.modellution.com/](https://www.modellution.com/)



Copyright (C) 2020-2024
