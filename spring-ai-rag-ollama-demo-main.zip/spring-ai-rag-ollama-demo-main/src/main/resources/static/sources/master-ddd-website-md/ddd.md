Domain-Driven Design :: SWT

[Home](http://homefgr.de) // [SWT](https://swt.homefgr.de)

Links

**GitHub**

[Kurs](https://github.fh-zwickau.de/whz-modul-pti09420-swt/)

- - -

[Teams](https://github.fh-zwickau.de/orgs/whz-modul-pti09420-swt/teams/studierende-2022ss)

- - -

**Erstellt mit**

[Antora](https://antora.org)

[![WHZ-Logo](https://upload.wikimedia.org/wikipedia/commons/thumb/a/ac/WHZ-Logo.svg/1200px-WHZ-Logo.svg.png)](https://www.fh-zwickau.de/pti/organisation/fachgruppe-informatik/homepage-der-fg-informatik/)

### [SWT](../index.html)

*   *   Überblick
    *   [Semesterplan](../semesterplan.html)
    *   [Semesterprojekt](../semesterprojekt.html)
*   *   Middleware
    *   [Zeitplan - Folien](../middleware/index.html)
    *   [Enterprise Application](../middleware/enterprise.html)
    *   [Entwickeln mit Spring](../middleware/spring.html)
    *   [Axon](../middleware/axon.html)
    *   [Axon und SAGA](../middleware/axon-saga.html)
    *   [Microservices](../middleware/microservices.html)
    *   [Projektaufbau](../middleware/microservices-implementing.html)
    *   [Security und OAuth2](../middleware/security-oauth2.html)
    *   [Eventual Consistency](../middleware/eventual-consistency.html)
    *   [Reaktive Anwendungen und Webflux](../middleware/reactive-programming.html)
    *   [Axon und Reactive](../middleware/reactive-axon.html)
    *   [Hexagonal Architecture](../middleware/hexagonal.html)
    *   [Pattern](../middleware/pattern.html)
*   *   DDD
    *   [Spezifikation](spezifikation.html)
    *   [DDD](ddd.html)
    *   [Praktikumsprojekt](praktikumsprojekt-2022.html)
*   *   Modellierung
    *   [Grundlagen](../modellierung/index.html)
    *   Ecore
        *   [Einführung](../modellierung/ecore.html)
    *   Xtext
        *   [Einführung](../modellierung/xtext.html#einfuehrung)
        *   [DSL für Zustandsautomaten](../modellierung/xtext.html#fowler-dsl)
        *   [Übung: DSL für DDD](../modellierung/xtext.html#ddd-dsl)

SWT 2024

*   [SWT](../index.html)

    *   [2024](../index.html)
    *   [2023](../../2023/index.html)

[](../index.html)

*   [SWT](../index.html)
*   DDD
*   [DDD](ddd.html)

2024

[2024](ddd.html) [2023](../../2023/ddd/ddd.html)

[Edit this Page](https://github.fh-zwickau.de/whz-modul-pti09420-swt/swt-website/blob/main/2024/modules/ddd/pages/ddd.adoc)

# Domain-Driven Design

> Wenn man gute Microservices bauen möchte, muss man DDD verstanden haben, sonst entsteht ein _Distributed Big Ball of Mud_ — und das ist noch viel schlimmer, als ein monolithischer _Big Ball of Mud_.

— Henning Schwentner (Mit-Erfinder von Domain Storytelling)

|     |     |
| --- | --- |
|     | Eine sehr gute Übersicht zu den nachfolgend beschriebenen DDD-Konzepten ist hier zu finden: [https://leanpub.com/ddd-referenz/read](https://leanpub.com/ddd-referenz/read). Es handelt sich um die von Michael Plöd ins Deutsche übersetze _Domain-Driven Design Referenz_ von Eric Evens. In den folgenden Abschnitten wird entsprechend auf die in der Referenz beschriebenen DDD-Konzepte verwiesen. |

DDD ist ein Ansatz der Softwareentwicklung und hilft dabei, hochwertige Software-Modellentwürfe anzufertigen. Das Ziel von DDD ist es, einen Entwurf zu entwickeln. Der Entwurf spiegelt genau wider, wie die Software arbeitet.

Der Ausschnitt der Realität, der betrachtet werden soll, ist der Teil, der mit der gewünschten, zu entwickelnden Software unterstützt werden soll. Dieser Ausschnitt wird in DDD _Domäne_ genannt: "A domain is the problem space that should be solved by designing a software." (Vernon, 2016)

Die Domäne ist der Kern von DDD. Am Anfang des Entwicklungsprozesses fehlt uns Softwareentwicklern vermutlich die genaue Kenntnis über die Domäne. Domänenexperten bzw. Fachexperten besitzen dieses Fachwissen. Den Fachexperten fehlen die Fähigkeiten und Fachbegriffe der Programmierung, um die Software umzusetzen. Deswegen müssen Entwickler- und Fachexpertengruppen kooperieren und sich einen gemeinsamen Wissensstand erarbeiten — auf Englisch _knowledge crunching_ genannt. DDD beginnt mit der Erstellung eines gemeinsamen Modells: "A central pillar is the domain model, which represents a view on the business domain of a use case." (Plöd, 2020) Alle Beteiligten sollten das Modell verstehen können. Die Domänenexperten müssen dem Modell zustimmen. Wichtig sind dabei vor allem die Fachbegriffe und -konzepte, die Fachexperten nutzen, um ihre Domäne und deren Abläufe zu beschreiben. Diese sind Teil der sogenannten allgegenwärtigen Sprache (engl.: _ubiquitous language_).

## [](#lehrbuch)Lehrbuch

Für die Einführung in DDD verwenden wir das Fachbuch (Khononov, 2022):

Vlad Khononov: Einführung in Domain-Driven Design: Von der Business-Strategie zum technischen Design (O’Reilly 2022).

Das Buch ist in elektronischer Fassung in der WHZ-Bibliothek verfügbar: [https://www.katalog.fh-zwickau.de/Record/0-1819227170](https://www.katalog.fh-zwickau.de/Record/0-1819227170).

## [](#strategisches-design)Strategisches Design

> In order to create good software, you have to know what that software is all about. You cannot create a banking software system unless you have a good understanding of what banking is all about, one must understand the domain of banking.

— A. Avram und F. Marinescu  
Domain-Driven Design Quickly (2006)

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#leanpub-auto-v-destillation-fr-strategic-design](https://leanpub.com/ddd-referenz/read#leanpub-auto-v-destillation-fr-strategic-design))

|     |     |
| --- | --- |
|     | Eine sehr gute Kurzübersicht zu den (hier nachfolgend besprochenen) Grundlagen des Strategischen DDD ist hier zu finden: [https://vaadin.com/learn/tutorials/ddd/strategic\_domain\_driven\_design](https://vaadin.com/learn/tutorials/ddd/strategic_domain_driven_design). |

|     |     |
| --- | --- |
|     | Einen weiteren sehr guten Einstieg in (Strategisches) DDD ist hier zu finden: [https://www.innoq.com/de/articles/2020/02/warum-domain-driven-design/](https://www.innoq.com/de/articles/2020/02/warum-domain-driven-design/). |

### [](#allgegenwärtige-sprache)Allgegenwärtige Sprache

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#ubiquitous-language](https://leanpub.com/ddd-referenz/read#ubiquitous-language))

Die allgegenwärtige Sprache verhindert Missverständnisse und Unklarheiten bei der Kommunikation zwischen Entwickler und Fachexperte. Softwareentwickler werden durch die Verwendung der allgegenwärtige Sprache daran erinnert, nicht in ihrer Fachsprache zu versinken, sodass der Fachexperte dem Gespräch nicht mehr folgen kann: "The Ubiquitous Language connects all the parts of the design, and creates the premise for the design team to function well." (A. Avram und F. Marinescu, Domain-Driven Design Quickly. 2006.)

Ein anderer Ansatz, dieses Kommunikationsproblem zu beherrschen, wäre das Übersetzen in die Sprache des Gesprächspartners. Übersetzungen erfordern jedoch einen signifikanten Mehraufwand und stumpfen die Kommunikation ab. (Evans, 2003) Deswegen sollte darauf verzichtet und eine gemeinsame Sprache verwendet werden. Die allgegenwärtige Sprache wird in den Modellen, den Gesprächen zwischen Entwickler und Fachexperte und in der Softwareimplementierung genutzt. Die Sprache wird basierend auf dem Modell entwickelt. Eine konsistente und richtige Nutzung der Sprache sollte regelmäßig überprüft werden. (Evans, 2003)

### [](#subdomänen)Subdomänen

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#core-domain](https://leanpub.com/ddd-referenz/read#core-domain), [https://leanpub.com/ddd-referenz/read#generic-subdomain](https://leanpub.com/ddd-referenz/read#generic-subdomain))

Wird ein grobes Domänenmodell entworfen, sollte es nicht vollumfänglich und detailliert sein. Es dient der Unterteilung in sogenannte Subdomänen. Für Subdomänen gibt es die Typen _Core Subdomain_, _Generic Subdomain_ und _Supporting Subdomain_. Eine _Core Subdomain_ ist eine Subdomäne, die vollständig dafür genutzt wird, die zentrale Funktionalität für die Anwendung bereitzustellen. Funktionalitäten, die für Core Subdomains entwickelte Software bietet, sind von strategischem Mehrwert für die Organisation, die die Software verwendet. Deshalb wir für die Entwicklung dieser Software DDD verwendet. Eine _Supporting Subdomain_ ist eine unterstützende Subdomäne, die essenziellen Mehrwert liefert, aber nicht den Kern der Anwendung darstellt. Für diese Art von Subdomäne muss daher selbst eine Softwarelösung entwickelt werden. Allerdings wird bei der Entwicklung pragmatisch vorgegangen. Aufgrund der (per Definition) geringen Komplexität von Supporting Subdomains kann bei deren Implementierung auch auf weniger empfehlenswerte Ansätze wir CRUD zurückgegriffen werden. Durch eine _Generic Subdomain_ wird dem zu entwickelnden Softwaresystem Funktionalität (und damit Komplexität) hinzugefügt, die notwendig, aber nicht essenziell ist. Meist gibt es fertige Softwarelösungen, die ohne signifikanten (Entwicklungs-)Aufwand integriert werden können.

### [](#bounded-contexts)Bounded Contexts

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#bounded-context](https://leanpub.com/ddd-referenz/read#bounded-context))

> Bounded context: A description of a boundary (typically a subsystem, or the work of a particular team) within which a particular model is defined and applicable.

— (Evens
2003)

|     |     |
| --- | --- |
|     | [Hier finden Sie einen Vortrag zu "Bounded Contexts richtig schneiden"](https://whz-bbb-scale.zw.fh-zwickau.de/playback/presentation/2.3/7897d67cc12cba8f260f1e6e4092f7ecc92b2d67-1616508781287?meetingId=7897d67cc12cba8f260f1e6e4092f7ecc92b2d67-1616508781287), den Michael Plöd im Sommer 2021 an der WHZ gehalten hat. |

Ein _Bounded Context_ (abgegrenzter Kontext) ist der Gültigkeitsbereich eines bestimmten Modells in Hinblick auf Terminologie, Konzepte und Regeln. (Evens, 2003) Jeder Bounded Context besitzt eine individuelle allgegenwärtige Sprache. Innerhalb eines Bounded Contexts gilt eine Terminologie, die in anderen Bounded Contexts in dieser Form nicht existiert. Ein erstrebenswertes Ziel ist es, jeden Bounded Context so zu entwerfen, dass er deckungsgleich mit genau einer Subdomäne ist (1-zu-1-Beziehung). Dies ist jedoch meist nur in sogenannten Green-Field-Projekten möglich, d. .h., Projekten, bei denen die gesamte Softwarelösung von Grund auf neu entwickelt wird. (Vernon, 2013) Jeder entstandene Bounded Context wird durch ein Domänenmodell detailliert beschrieben.

> The boundary around a domain model is very important for DDD. That’s where contextual dialogue begins and ends. Contextual boundaries and deployment units are two different things. Deployment is tech and may be considered a service, but context rules.

— Vaughn Vernon

### [](#context-mapping)Context Mapping

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#context-map](https://leanpub.com/ddd-referenz/read#context-map))

> A Context Map is a document which outlines the different Bounded Contexts and the relationships between them.

— A. Avram und F. Marinescu  
Domain-Driven Design Quickly (2006)

|     |     |
| --- | --- |
|     | [Hier finden Sie einen Vortrag zu Context Mapping und soziotechnischen Systemen](https://whz-bbb-scale.zw.fh-zwickau.de/playback/presentation/2.3/7897d67cc12cba8f260f1e6e4092f7ecc92b2d67-1620306953176?meetingId=7897d67cc12cba8f260f1e6e4092f7ecc92b2d67-1620306953176), den Michael Plöd im Sommer 2021 an der WHZ gehalten hat. Die Folien zu diesem Vortrag finden Sie hier: [https://speakerdeck.com/mploed/visualizing-sociotechnical-architectures-with-context-maps](https://speakerdeck.com/mploed/visualizing-sociotechnical-architectures-with-context-maps). |

|     |     |
| --- | --- |
|     | Eine sehr gute Visualisierung (Diagramme) der im Folgenden vorgestellten Context-Mapping-Beziehungen gibt es hier: [https://github.com/ddd-crew/context-mapping](https://github.com/ddd-crew/context-mapping). |

|     |     |
| --- | --- |
|     | [Hier finden Sie mehrere Beispiele zu konkreten Contexts Maps](https://contextmapper.org/docs/examples/) (diese sind mit dem [Context Mapper-Tool](https://contextmapper.org) entwickelt worden; aber auch ohne Blick auf das Tool bieten die Context Maps wertvolle Einblicke in das Thema Context Mapping). |

Eine Context Map stellt die Beziehungen zwischen den Bounded Contexts einer Domäne explizit in einem Modell dar — mit anderen Worten: Beziehungen zwischen BCs werden mithilfe eines Context-Mapping-Diagramms visualisiert. Aus Sicht des Context Mappings existieren verschiedene Arten von Beziehungen zwischen BCs.

Eine erste Art stellt die _Upstream-Downstream-Beziehung_ dar. Beispiel: Ein Studierendenverwaltungssystem verhält sich _upstream_ zu einem Notenverwaltungssystem. Der Erfolg des _Downstream-Bounded-Contexts_ (D-BC) ist abhängig vom _Upstream-Bounded-Context_ (U-BC). Gäbe es keine Studierendenverwaltung (U-BC), könnten keine Noten erfasst werden (D-BC). Jedoch ist die Beeinflussung oder Abhängigkeit in umgekehrter Richtung nicht (signifikant) ausgeprägt. Studierende können weiterhin verwaltet werden, auch wenn die Notenverwaltung nicht existent oder ausgefallen ist. Ein U-BC kann ohne einen D-BC erfolgreich funktionieren.

Zusätzlich zur Definition von U-BC und D-BC gibt es verschiedene Arten von Beziehungen zwischen den Kontexten. Diese Beziehungen werden auch _Integration Patterns_ genannt. Sie werden im Folgenden beschrieben:

#### [](#customer-supplier)Customer-Supplier

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#customer-supplier](https://leanpub.com/ddd-referenz/read#customer-supplier))

Die _Customer-Supplier_\-Beziehung beschreibt, dass der Customer (D-BC) dem Supplier Erwartungen zu zum Beispiel Schnittstellen mitteilen kann. Der Supplier kann die Erwartungen erfüllen — oder auch nicht. Der Customer ist vom Supplier abhängig.

#### [](#conformist)Conformist

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#conformist](https://leanpub.com/ddd-referenz/read#conformist))

Als Verschärfung der Customer-Supplier-Beziehung kann die _Conformist_\-Beziehung gesehen werden. Die Rolle des Conformist kann einem D-BC zugeordnet werden. Anders als bei der _Customer-Supplier_\-Beziehung nimmt ein U-BC keine Notiz von den D-BCs. Ein U-BC wird seine Schnittstellen nicht auf Anforderung des D-BC anpassen. Der D-BC (d. h. der Conformist-BC) muss mit den vom U-BC zur Verfügung gestellten Schnittstellen auskommen.

#### [](#partnership)Partnership

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#partnership](https://leanpub.com/ddd-referenz/read#partnership))

Zwei Bounded Contexts verbindet eine _Partnership_, wenn beider Erfolg eng miteinander verbunden ist. Die Entwicklerteams der beiden Kontexte sollten eng zusammenarbeiten, denn wenn ein Team scheitert, wird das andere ebenfalls scheitern.

#### [](#shared-kernel)Shared Kernel

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#shared-kernel](https://leanpub.com/ddd-referenz/read#shared-kernel))

Eine im Vergleich zur Partnership-Beziehung noch ausgeprägtere Form des Zusammenspiels ist der _Shared Kernel_. Dabei wird ein Domänenmodell oder Teile eines Modells und der zugehörige Code gemeinsam von beiden BCs (und den entsprechenden Entwicklungsteams) verwendet. Es entstehen dadurch ausgeprägte wechselseitige Abhängigkeiten.

#### [](#separate-ways)Separate Ways

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#separate-ways](https://leanpub.com/ddd-referenz/read#separate-ways))

Mit dieser Art Beziehung wird (in der Context Map) explizit festgehalten, dass ein Bounded Context gar keine Verbindung zu einem bestimmten anderen BC hat.

#### [](#open-host-service)Open-Host Service

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#open-host-service](https://leanpub.com/ddd-referenz/read#open-host-service))

Integrieren mehrere (Downstream-)BCs einen bestimmten (Upstream-)BC mithilfe derselben Schnittstellen, kann der genutzte BC als _Open-Host Service_ gekennzeichnet werden. Ein Open-Host Service geht nicht einzeln auf jeden abhängigen BC ein (zum Beispiel in Form der Übersetzung seines Domänenmodells in eine vom abhängigen BC gewünschte andere Form), sondern bietet standardisierte Schnittstellen an. Mit Open-Host Service wird oft mit dem Konzept Published Language kombiniert (welche nachfolgend vorgestellt wird). (Vernon, 2013; Plöd, 2020)

#### [](#published-language)Published Language

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#published-language](https://leanpub.com/ddd-referenz/read#published-language))

_Published Language_ erfordert eine gut dokumentierte Sprache, die von allen zu integrierenden BCs verwendet wird. Diese Sprache wird als Standard-Kommunikationsmedium festgelegt. _Mehrere_ Parteien stimmen der Festlegung zu.

Der Vorteil von Published Language ist die Entkopplung der BCs. Jeder Kontext kann sich mithilfe der Published Language Übersetzungen in sein eigenes Modell bauen und dieses Modell ggf. später auch verändern. Andere BCs — vor allem der die PL zur Verfügung stellende (Upstream-)BC — sind unabhängig, da Kommunikation nur mit der festgelegten gemeinsamen Sprache stattfindet.

|     |     |
| --- | --- |
|     | Normalerweise ist die Published Language _nicht_ identisch mit dem Domänenmodell des U-BC. Die PL stellt die gemeinsame Sprache dar, auf die sich geeinigt wurde. |

#### [](#anticorruption-layer)Anticorruption Layer

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#anticorruption-layer](https://leanpub.com/ddd-referenz/read#anticorruption-layer))

Interagiert ein D-BC mit einem seiner U-BC, kann der D-BC eine _Anticorruption Layer_ (ACL) verwenden. Die ACL übersetzt das Modell des U-BC in das des D-BC. Ändern sich Schnittstellen des U-BC, muss der D-BC nur Änderungen in der ACL vornehmen und nicht das eigene Modell anpassen. Die Kopplung erfolgt demnach in der ACL und beeinflusst nicht direkt das (interne) Domänenmodell. (Vernon, 2013; Plöd, 2020)

|     |     |
| --- | --- |
|     | Auf Deutsch sollte das englische "Anticorruption" besser als "Anti-Korrumpierung" (im Sinne von "verschlechtern" oder "verderben"; das Wort "rumpere" bedeutet "(zer)brechen") übersetzt werden. |

#### [](#big-ball-of-mud-bbom)Big Ball of Mud (BBoM)

(DDD-Referenz: [https://leanpub.com/ddd-referenz/read#big-ball-of-mud](https://leanpub.com/ddd-referenz/read#big-ball-of-mud))

Brian Foote und Joseph Yoder definieren den BBoM hier: [http://www.laputan.org/mud/mud.html](http://www.laputan.org/mud/mud.html).

## [](#taktisches-design)Taktisches Design

Siehe [https://leanpub.com/ddd-referenz/read#leanpub-auto-ii-bestandteile-eines-modellgetriebenen-entwurfs](https://leanpub.com/ddd-referenz/read#leanpub-auto-ii-bestandteile-eines-modellgetriebenen-entwurfs)

## [](#literatur-und-weiterführendes-material)Literatur und weiterführendes Material

### [](#folien)Folien

*   [Folien zu DDD (PDF-Format)](_attachments/ddd.pdf)


### [](#videokurs-zu-ddd-cqrs-und-event-sourcing)Videokurs zu DDD, CQRS und Event Sourcing

Dieser (englischsprachige) **Videokurs zu DDD, CQRS und Event Sourcing** ist in Zusammenarbeit mit [Alexander Lawrence](https://www.alex-lawrence.com/), Softwarearchitekt und Autor von [_Implementing DDD, CQRS and Event Sourcing_](https://leanpub.com/implementing-ddd-cqrs-and-event-sourcing) entstanden.

*   Video 1: [Überblick Enterprise-Software](../_attachments/videokurs/1%20-%20enterprise-software.mp4)

    *   [Folien](../_attachments/videokurs/1%20-%20enterprise-software.pdf)


*   Video 2: [Überblick Softwarearchitektur](../_attachments/videokurs/2%20-%20software-architecture.mp4)

    *   [Folien](../_attachments/videokurs/2%20-%20software-architecture.pdf)


*   Video 3: [Einstieg DDD](../_attachments/videokurs/3%20-%20getting-started-with-ddd.mp4)

    *   [Folien](../_attachments/videokurs/3%20-%20getting-started-with-ddd.pdf)


*   Video 4: [Taktisches Design](../_attachments/videokurs/4%20-%20tactical-design.mp4)

    *   [Folien](../_attachments/videokurs/4%20-%20tactical-design.pdf)


*   Video 5: [Aggregates (Teil 1)](../_attachments/videokurs/5%20-%20aggregates-pt-1.mp4)

    *   [Folien](../_attachments/videokurs/5%20-%20aggregates-pt-1.pdf)


*   Video 6: [Domain Events](../_attachments/videokurs/6%20-%20domain-events.mp4)

    *   [Folien](../_attachments/videokurs/6%20-%20domain-events.pdf)


*   Video 7: [Aggregates (Teil 2)](../_attachments/videokurs/7%20-%20aggregates-pt-2.mp4)

    *   [Folien](../_attachments/videokurs/7%20-%20aggregates-pt-2.pdf)


*   Video 8: [CQRS](../_attachments/videokurs/8%20-%20cqrs.mp4)

    *   [Folien](../_attachments/videokurs/8%20-%20cqrs.pdf)


*   Video 9: [Event Sourcing](../_attachments/videokurs/9%20-%20event-sourcing.mp4)

    *   [Folien](../_attachments/videokurs/9%20-%20event-sourcing.pdf)



### [](#ddd)DDD

*   Evans, E. (2003). Domain-driven Design: Tackling complexity in the heart of software. Addison-Wesley.

*   Vernon, V. (2013). Implementing Domain-Driven Design. Addison-Wesley.

*   Vernon, V. (2016). Domain-Driven Design Distilled. Addison-Wesley.

*   Vernon, V. (2017). Domain-Driven Design kompakt. dpunkt.verlag.

*   Vernon, V.; Jaskula T. (2021). Strategic Monoliths and Microservices: Driving Innovation Using Purposeful Architecture. Addison-Wesley.

*   Plöd, M. (2020). Hands-on Domain-driven Design — by example. Leanpub.

*   Lawrence, A. (2019). Implementing DDD, CQRS and Event Sourcing. Leanpub.

*   Khononov, V. (2019). What Is Domain-Driven Design?. O’Reilly Media.

*   Khononov, V. (2022). Learning Domain-Driven Design. O’Reilly Media.

*   Zimarev, A. (2019). Hands-On Domain-Driven Design with .NET Core. Packt Publishing.


### [](#strategisches-ddd)Strategisches DDD

*   Tune, N. (2019, Juli 22). [Modelling Bounded Contexts with the Bounded Context Canvas: A Workshop Recipe](https://medium.com/nick-tune-tech-strategy-blog/modelling-bounded-contexts-with-the-bounded-context-design-canvas-a-workshop-recipe-1f123e592ab).

*   Tune, N. et al. (2021). [Bounded Context Canvas](https://github.com/ddd-crew/bounded-context-canvas).

*   [Video von Eberhard Wolf zum taktischen Domain-driven Design](https://www.youtube.com/watch?v=KsY1KbZo7fQ)


### [](#ddd-und-microservices)DDD und Microservices

*   Newman, S. (2019). Monolith to Microservices. O’Reilly Media.

*   Newman, S. (2021). Building Microservices (2nd Ed.). O’Reilly Media.


Copyright (C) 2020-2024
