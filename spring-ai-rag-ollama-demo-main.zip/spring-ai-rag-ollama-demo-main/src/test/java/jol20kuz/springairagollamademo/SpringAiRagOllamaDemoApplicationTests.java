package jol20kuz.springairagollamademo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringAiRagOllamaDemoApplicationTests {

    @Test
    void contextLoads() {
    }
}
