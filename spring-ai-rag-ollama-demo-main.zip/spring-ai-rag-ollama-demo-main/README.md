# Setup & Start

Es wird Ollama mit Llama3.2 genutzt.
Wie das zum Laufen gebracht werden kann wird 
[hier (VPN notwendig)](https://github.fh-zwickau.de/jol20kuz/spring-ai-ollama-demo/blob/main/README.md) 
bereits beschrieben.

Als VektorStore wird aktuell eine einfache JSON-Datei verwendet.

## Testquellen einfügen

Testquellen müssen in dem Ordner `src/main/resources/static/sources/<experiment-name>` eingefügt werden.
Die Quellen stehen nur den Prompts mit dem gleichen Experimentnamen zur Verfügung.

## Testprompts einfügen

Testprompts müssen in dem Ordner `src/main/resources/static/prompts/<experiment-name>` eingefügt werden.
Die Dateienden müssen auf `.pmpt` oder `.prompt` enden.

## Ergebnisse der Experimente

Die Ergebnisse der Experimente lassen sich im Verzeichnis `build/resources` finden.

## Bestimmtes Experiment ausführen

Um ein bestimmtes Experiment auszuführen, muss der Experimentname in der `application.properties` unter 
`experiment.perform` angegeben werden. Wenn mehrere ausgeführt werden sollen, können die Namen mit einem Komma 
getrennt werden. Wenn alle ausgeführt werden sollen, dann freilassen.

# Quellen
- ([Spring AI & Redis](https://docs.spring.io/spring-ai/reference/api/vectordbs/redis.html))
- ([Redis Docker (inkl. JSON)](https://stackoverflow.com/a/72887858/14080735))
- [Grundbausteine (VPN notwendig)](https://github.fh-zwickau.de/jol20kuz/spring-ai-ollama-demo/blob/main/README.md)
- [Spring AI & RAG](https://youtu.be/4-rG2qsTrAs?si=XDT-f_XAEG1ExI94)